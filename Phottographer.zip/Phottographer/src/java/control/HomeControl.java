/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import entity.Contact;
import entity.Gallery;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Funny
 */
public class HomeControl extends BaseControl {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String indexString = request.getParameter("index");
            int check = 0;
            int index = 0;
            //the fist time run project then auto index get value 1
            if (indexString == null) {
                indexString = "1";
            }
            try {
                index = Integer.parseInt(indexString);
                check = 1;
            } catch (Exception e) {
                request.setAttribute("error", "Gallery invalid");
            }
            //check if index valid then post data to homePage 
            if (check == 1) {
                int size = 3;
                int count = dao.countGallery();
                int lastPage = count / size;
                //if total number gallery search indivisible size then last page add one more
                if (count % size != 0) {
                    lastPage++;
                }
                List<Gallery> listGal = dao.pagingGallery(index, size);
                request.setAttribute("listG", listGal);
                request.setAttribute("index", index);
                request.setAttribute("lastPage", lastPage);
            }
            Contact c = dao.getContact();
            request.setAttribute("contact", c);
            request.getRequestDispatcher("HomePage.jsp").forward(request, response);
        } catch (Exception ex) {
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    @Override
    protected void processGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void processPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
