/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import entity.Gallery;
import entity.Image;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Funny
 */
public class DetailControl extends BaseControl {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String idString = request.getParameter("id");
            String indexString = request.getParameter("index");
            String imgString = request.getParameter("imageID");
            int id = 0;
            int index = 0;
            int imgID = 0;
            int check1 = 0, check2 = 0, check3 = 0;
            // check set value id is 1 for the first time run
            if (idString == null) {
                idString = "1";
            }
            // check set value index is 1 for the first time run
            if (indexString == null) {
                indexString = "1";
            }
            try {
                id = Integer.parseInt(idString);
                check1 = 1;
                try {
                    index = Integer.parseInt(indexString);
                    check2 = 1;
                    try {
                        //if imgID null then set imgID is the top 1 picture by galleryID 
                        if (imgString == null) {
                            imgID = dao.getImageID(id).getId();
                            //if imgID not null set imgID byimgID
                        } else {
                            imgID = Integer.parseInt(imgString);
                        }
                        check3 = 1;
                    } catch (Exception e) {
                        request.setAttribute("error1", "Invalid imageID");
                    }
                } catch (Exception e) {
                    request.setAttribute("error1", "Invalid value index");
                }
            } catch (Exception e) {
                request.setAttribute("error1", "Invalid value id");
            }
            //if id , index and imgID not null then get data 
            if (check1 == 1 && check2 == 1 && check3 == 1) {
                int count = dao.countImage(id);
                int size = 8;
                int lastPage = count / size;
                //if total number pictures search indivisible size then last page add one more 
                if (count % size != 0) {
                    lastPage++;
                }
                Image image = dao.getImageDetail(imgID, id);
                if(image  == null){
                    request.setAttribute("error2", "Not found Image!");
                }
                Gallery detail = dao.getGallerybyID(id);
                request.setAttribute("detail", detail);
                List<Image> listImage = dao.pagingImage(id, index, size);
                request.setAttribute("lastPage", lastPage);
                request.setAttribute("index", index);
                request.setAttribute("listI", listImage);
                request.setAttribute("galleryID", id);
                request.setAttribute("imageDetail", image);
            }
            request.getRequestDispatcher("Gallery.jsp").forward(request, response);
        } catch (Exception e) {
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    @Override
    protected void processGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void processPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

}
