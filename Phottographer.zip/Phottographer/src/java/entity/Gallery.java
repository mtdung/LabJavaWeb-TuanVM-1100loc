/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import DAO.GalleryDAO;
import context.DBContext;

/**
 *
 * @author Funny
 */
public class Gallery {
    private int id;
    private String title;
    private String name;
    private String description;
    private Image image;

    public Gallery() {
    }

    public Gallery(int id, String title, String name, String description) {
        this.id = id;
        this.title = title;
        this.name = name;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Image getImage() throws Exception {
        return new GalleryDAO().getImageID(id);
    }

    public void setImage(Image image) {
        this.image = image;
    }   
}
