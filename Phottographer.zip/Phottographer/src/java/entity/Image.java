/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import context.DBContext;

/**
 *
 * @author Funny
 */
public class Image {
    private int id;
    private int gid;
    private String url;

    public Image() {
    }

    public Image(int id, int gid, String url) {
        this.id = id;
        this.gid = gid;
        this.url = url;
    }

    public int getGid() {
        return gid;
    }

    public void setGid(int gid) {
        this.gid = gid;
    }
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUrl() throws Exception {
        return new DBContext().getImage() + url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
