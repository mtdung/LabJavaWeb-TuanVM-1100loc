/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import context.DBContext;

/**
 *
 * @author Funny
 */
public class Share {
    private String icon;
    private String name;
    private String url;

    public Share() {
    }

    public Share(String icon, String name, String url) {
        this.icon = icon;
        this.name = name;
        this.url = url;
    }

    public String getIcon() throws Exception {
        return new DBContext().getImage() + icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
    
}
