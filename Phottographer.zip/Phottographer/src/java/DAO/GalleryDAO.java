/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import context.DBContext;
import entity.Contact;
import entity.Gallery;
import entity.Image;
import entity.Share;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Funny
 */
public class GalleryDAO {

    public List<Gallery> getTop3Gallery() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Gallery> list = new ArrayList<>();
        String query = "select  top 3 *\n"
                + "from gallery";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Gallery(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("name"),
                        rs.getString("description")));
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }

    public List<Share> getLinkShare() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Share> list = new ArrayList<>();
        String query = "select * from Share";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Share(rs.getString("icon"),
                        rs.getString("NameSocial"),
                        rs.getString("Link")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }

    public Contact getContact() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select * from Contact";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Contact(rs.getString("telephone"), rs.getString("email"),
                        rs.getString("address"), rs.getString("city"),
                        rs.getString("country"), rs.getString("map_url"),
                        rs.getString("about"), rs.getString("image_main"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }

    public int countGallery() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        String query = "select count(*) from gallery ";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return count = rs.getInt(1);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return count;
    }

    public List<Gallery> pagingGallery(int index, int size) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Gallery> list = new ArrayList<>();
        String query = "select * from gallery \n"
                + "Order by id OFFSET ? ROWS\n"
                + "FETCH NEXT ? ROWS ONLY";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, (index - 1) * size);
            ps.setInt(2, size);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Gallery(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("name"),
                        rs.getString("description")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }

    public Image getImageID(int galleryid) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select top 1 * from Images \n"
                + "where galleryID = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, galleryid);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Image(rs.getInt("id"), rs.getInt("galleryID"),
                        rs.getString("imageLink"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }

    public Gallery getGallerybyID(int id) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select * from gallery where id = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Gallery(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("name"),
                        rs.getString("description"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }

    public int countImage(int id) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        String query = "select count(*) from Images\n"
                + "where galleryID = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return count = rs.getInt(1);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return count;
    }

    public List<Image> pagingImage(int id, int index, int size) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Image> list = new ArrayList<>();
        String query = "select * from Images where galleryID = ?\n"
                + "ORDER BY id OFFSET ? ROWS \n"
                + "FETCH NEXT ? ROWS ONLY";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ps.setInt(2, (index - 1) * size);
            ps.setInt(3, size);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Image(rs.getInt("id"), rs.getInt("galleryID"), rs.getString("imageLink")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }

    public Image getImageDetail(int imgID, int galID) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select * from Images \n"
                + "where id = ? and galleryID = ? ";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1 , imgID);
            ps.setInt(2, galID);
            rs = ps.executeQuery();
            while(rs.next()){
                return new Image(rs.getInt("id"), 
                        rs.getInt("galleryID"), 
                        rs.getString("imageLink"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }
}
